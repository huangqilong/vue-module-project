// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import 'babel-polyfill'
import Vue from 'vue'
import axios from 'axios'
import store from './store'
import VueRouter from 'vue-router'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import './css/common.css'
import './css/iconfont.css'
import './css/icon-extend.css'

import routes from './config/routes'
import App from './App'

Vue.use(VueRouter) // 路由注册
Vue.use(ElementUI) // UI框架注册

/*
* 在创建的 router 对象中，如果不配置 mode，就会使用默认的 hash 模式，该模式下会将路径格式化为 #! 开头。
 添加 mode: 'history' 之后将使用 HTML5 history 模式，该模式下没有 # 前缀，而且可以使用 pushState 和 replaceState 来管理记录。
* */
const router = new VueRouter({
  routes: routes
})

router.beforeEach(({meta, path}, from, next) => {
  /*
  let {auth = true} = meta
  let isLogin = Boolean(store.state.login.session.tokens !== '') // true用户已登录， false用户未登录

  if (auth && !isLogin && path !== '/login') {
    return next({path: '/login'})
  }

  if (isLogin && (path === '/login' || path === '/')) { // 已登录过，则跳转到主页
    return next({path: '/home/index'})
  } */
  next()
})

router.afterEach(({meta, path}, from) => {

})

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
  // 在发送请求之前做些什么
  /*
  if (store.state.login.session.tokens) {
    config.headers.common['jwtToken'] = store.state.login.session.tokens
    config.headers.common['userId'] = store.state.login.session.userId
    config.headers.post['Content-Type'] = 'application/json'
  } */
  if (config.url.indexOf('/user/logout') === -1) {
    store.dispatch('setButtonLoading', true)
  }
  return config
}, function (error) {
  store.dispatch('setButtonLoading', false)
  // 对请求错误做些什么
  return Promise.reject(error)
})

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
  store.dispatch('setButtonLoading', false)
  if (response.data.code === 1025) {
    store.commit('login/LOGIN_OUT')
    store.commit('dictionary/DICT_LOGIN_OUT')
    router.replace({
      path: 'login',
      query: {redirect: router.currentRoute.fullPath}
    })
  }
  // 请求认证失败
  return response
}, function (error) {
  store.dispatch('setButtonLoading', false)
  if (error.response) {
    switch (error.response.status) {
      case 401:
        // 返回 401 清除token信息并跳转到登录页面
        store.commit('login/LOGIN_OUT')
        store.commit('dictionary/DICT_LOGIN_OUT')
        router.replace({
          path: 'login',
          query: {redirect: router.currentRoute.fullPath}
        })
    }
  }
  // 对响应错误做点什么
  return Promise.reject(error)
})

new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
