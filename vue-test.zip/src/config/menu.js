/**
 * Created by huangjinbiao on 2017/8/7.
 */
export default [
  {
    id: 'home-index',
    name: '首页',
    iconClass: 'el-icon-document',
    path: '/home/index'
  },
  {
    id: 'home-menu-1',
    name: '测试页一',
    iconClass: 'el-icon-document',
    path: '/home/menu/first'
  },
  {
    id: 'home-menu-2',
    name: '测试菜单',
    iconClass: 'el-icon-document',
    items: [
      {
        id: 'home-menu-3',
        name: '测试页三',
        iconClass: '',
        path: '/home/menu/third'
      },
      {
        id: 'home-menu-4',
        name: '测试页四',
        iconClass: '',
        path: '/home/menu/fourth'
      }
    ]
  }
]
