/**
 * auth true登录才能访问，false不需要登录，默认true
 */
export default [
  { path: '*', component: resolve => require(['../modules/login/'], resolve) },
  {
    path: '/login',
    meta: {auth: false},
    component: resolve => require(['../modules/login/'], resolve)
  },
  {
    path: '/',
    meta: {auth: false},
    redirect: '/login'
  },
  {
    path: '/home',
    meta: {auth: true},
    component: resolve => require(['../modules/home/'], resolve),
    children: [
      {
        path: 'index',
        meta: {auth: true},
        component: resolve => require(['../modules/index'], resolve)
      },
      {
        path: 'menu/first',
        meta: {auth: true},
        component: resolve => require(['../modules/menu/first'], resolve)
      },
      {
        path: 'menu/third',
        meta: {auth: true},
        component: resolve => require(['../modules/menu/third'], resolve)
      },
      {
        path: 'menu/fourth',
        meta: {auth: true},
        component: resolve => require(['../modules/menu/fourth'], resolve)
      }
    ]
  }
]
