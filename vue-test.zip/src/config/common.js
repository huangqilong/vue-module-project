/**
 * Created by huangjinbiao on 2017/7/5.
 */
// pageInfo
export const PAGE_NUMBER = 50
