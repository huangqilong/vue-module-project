/**
 * Created by hjb on 2017/2/7.
 */
// common
export const COMMON = {
  COM_OPTION_PARAMS: 'common/COM_OPTION_PARAMS',
  COM_BUTTON_LOADING: 'common/COM_BUTTON_LOADING'
}
// 登录
export const LOGIN = {
  LOGIN_IN: 'login/LOGIN_IN',
  LOGIN_OUT: 'login/LOGIN_OUT'
}
