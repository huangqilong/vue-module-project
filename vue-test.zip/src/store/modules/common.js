import {PAGE_NUMBER} from '../../config/common'
import {PROXY_DEV_API} from '../../apis/api-type'
import {COMMON} from '../mutation-types'
// initial state
const state = {
  pageNumber: PAGE_NUMBER,
  optionParams: null,
  buttonLoading: false,
  proxyDevApi: PROXY_DEV_API
}

// getters
const getters = {
  pageNumber: state => state.pageNumber,
  optionParams: state => state.optionParams,
  buttonLoading: state => state.buttonLoading,
  proxyDevApi: state => state.proxyDevApi
}

// actions
const actions = {
  setOptionParams ({commit, state}, params) {
    commit(COMMON.COM_OPTION_PARAMS, params)
  },
  setButtonLoading ({commit, state}, params) {
    commit(COMMON.COM_BUTTON_LOADING, params)
  }
}

// mutations
const mutations = {
  [COMMON.COM_OPTION_PARAMS] (state, data) {
    state.optionParams = data
  },
  [COMMON.COM_BUTTON_LOADING] (state, data) {
    if (data) {
      state.buttonLoading = true
    } else {
      state.buttonLoading = false
    }
  }
}

// export
export default {
  state,
  getters,
  actions,
  mutations
}
