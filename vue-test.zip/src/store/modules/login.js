
import {LOGIN} from '../mutation-types'

// initial state
const state = {
  session: {
    userName: '测试用户',
    userId: '',
    tokens: '',
    cRealName: '测试用户',
    headersFile: null
  }
}

// getters
const getters = {
  userName: state => state.session.userName,
  tokens: state => state.session.tokens,
  userId: state => state.session.userId,
  cRealName: state => state.session.cRealName,
  headersFile: state => state.session.headersFile
}

// actions
const actions = {
  login ({commit, state}, data) {
    commit(LOGIN.LOGIN_IN, data)
  },
  logout ({commit}) {
    commit(LOGIN.LOGIN_OUT)
  }
}

// mutations
const mutations = {
  [LOGIN.LOGIN_IN] (state, data) {
    /*
    state.session.userName = data.cUserName
    state.session.tokens = data.jwtToken
    state.session.userId = data.iUserId
    state.session.cRealName = data.cRealName
    state.session.headersFile = {
      jwtToken: data.jwtToken,
      userId: data.iUserId
    } */
  },
  [LOGIN.LOGIN_OUT] (state) {
    /*
    state.session.userName = ''
    state.session.tokens = ''
    state.session.userId = ''
    state.session.cRealName = ''
    state.session.headersFile = null */
  }
}
// export
export default {
  state,
  getters,
  actions,
  mutations
}
