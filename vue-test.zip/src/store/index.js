/**
 * Created by lichb on 2017/2/7.
 */
import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger'
import createPersistedState from 'vuex-persistedstate'
import * as state from './state'
import * as mutations from './mutations'
import * as actions from './actions'
import * as getters from './getters'
import common from './modules/common'
import login from './modules/login'

Vue.use(Vuex)

const debug = process.env.NODE_ENV !== 'production'
/*
* vuex的数据持久化支持，默认localStorage

 vuex2与cookie的持久化支持
 let persistedState = {
 paths: ['login'],
 getState: (key) =>  Cookies.getJSON(key),
 setState: (key, state) => Cookies.set(key, state, {expires: 3}) //expires->cookie过期时间，单位为天
 }
* */
let modulesArray = {
  common,
  login
}
let persistedModulesArray = {
  login
}
let perLocalModulesArray = {
}
const getPlugins = () => {
  const plugins = []
  for (let model in perLocalModulesArray) {
    // localStorage存储
    plugins.push(createPersistedState({
      key: model + '-local',
      paths: [model + '.local']
    }))
    /*
    // cookieStorage存储
    plugins.push(createPersistedState({
      key: model + '-cookie',
      paths: [model + '.cookie'],
      getState: (key) => Cookies.getJSON(key),
      setState: (key, state) => Cookies.set(key, state, {expires: 1})
    }))
    */
  }
  for (let model in persistedModulesArray) {
    // sessionStorage存储
    plugins.push(createPersistedState({
      key: model + '-session',
      storage: window.sessionStorage,
      paths: [model + '.session']
    }))
  }
  if (debug) {
    plugins.unshift(createLogger())
  }
  return plugins
}

export default new Vuex.Store({
  state,
  mutations,
  actions,
  getters,
  modules: modulesArray,
  strict: debug,
  plugins: getPlugins()
})
