<template>
  <transition name="fade">
    <router-view></router-view>
  </transition>
</template>
