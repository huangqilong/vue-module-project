<style>

</style>
<template>
  <span>项目测试页三</span>
</template>
<script>
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
      }
    },
    computed: {
      ...mapGetters([
      ])
    },
    watch: {
    },
    created: function () {
    },
    methods: {
    }
  }
</script>
