/**
 * Created by huangjinbiao on 2017/7/12.
 */
// 开发代理配置
export const PROXY_DEV_API = '/devapi'
