<style scoped>

</style>
<template>
  <el-submenu :index="menu.id+''">
    <template slot="title"><i :class="menu.cIcon|| 'el-icon-document'"></i>{{menu.name}}</template>
    <template v-for="item in menu.items">
      <template v-if="item.items && item.items.length>0">
        <c-sub-menu :menu="item"></c-sub-menu>
      </template>
      <template v-else>
        <el-menu-item :index="item.id+''" @click="menuItemSelect(item)"><i :class="item.cIcon"></i>{{item.name}}</el-menu-item>
      </template>
    </template>

  </el-submenu>
</template>
<script>
  export default {
    name: 'cSubMenu',
    props: ['menu'],
    methods: {
      menuItemSelect (menu) {
        this.$router.push(menu.path)
      }
    }
  }
</script>
