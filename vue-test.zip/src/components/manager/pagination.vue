<style scoped>
  .pagination{
    text-align: center;
    margin: 30px 0 10px;
  }

</style>
<style>
  .pagination .el-pagination button, .pagination .el-pagination span {
    font-size: 14px;
    min-width: 35px;
    line-height: 30px;
    height: 30px;
    margin: 0 5px;
  }
  .pagination .el-pagination .el-select .el-input{
    line-height: 30px;
  }
  .pagination .el-pagination .el-select .el-input input{
    height: 30px;
    font-size: 14px;
  }
  .pagination .el-pagination .btn-prev {
    border-right: 1px solid #d1dbe5;
  }
  .pagination .el-pagination .btn-next {
    border-left: 1px solid #d1dbe5;
  }
  .pagination  .el-pager li {
    border-right: 1px solid #d1dbe5;
    font-size: 14px;
    min-width: 35px;
    height: 30px;
    margin: 0 5px;
  }
  .pagination .el-pager li.active {
    border-color: #20a0ff;
  }
</style>
<template>
  <div class="pagination">
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pageData.currentPage"
      :page-sizes="[10, 30, 50, 100, 500]"
      :page-size="pageData.number"
      layout="total,sizes, prev, pager, next"
      :total="pageData.totalCount"></el-pagination>
  </div>
</template>
<script>
  export default{
    name: 'pagination',
    props: ['pageData'],
    data () {
      return {
      }
    },
    created: function () {
    },
    methods: {
      handleSizeChange (val) {
        this.pageData.callPageChange(1, val)
      },
      handleCurrentChange (val) {
        this.pageData.callPageChange(val)
      }
    }
  }
</script>
