<style scoped>
  .main-sidebar {
    position: fixed;
    top: 80px;
    width: 230px;
    background-color: #545c64;
    overflow-y: auto;
    bottom: 0;
  }
</style>
<style>
  .main-sidebar .el-menu {
    border-right: solid 1px #545c64;
  }
</style>
<template>
  <nav class="main-sidebar">
    <el-menu class="el-menu-vertical-demo"
             theme="dark"
             :unique-opened="true"
             :default-active="activeIndex"
             background-color="#545c64"
             text-color="#fff"
             active-text-color="#ffd04b">
      <template v-for="menu in dataMenuConfig">
        <template v-if="menu.items && menu.items.length>0">
          <c-sub-menu :menu="menu"></c-sub-menu>
        </template>
        <template v-else>
          <el-menu-item :index="menu.id+''" @click="menuItemSelect(menu)"><i class="el-icon-document"></i>{{menu.name}}</el-menu-item>
        </template>
      </template>
    </el-menu>
  </nav>
</template>
<script>
  import {mapGetters} from 'vuex'
  import menuConfig from '../config/menu'
  import CSubMenu from '../components/CSubMenu'

  export default {
    name: 'cMenu',
    components: {
      CSubMenu
    },
    data () {
      return {
        activeIndex: 'home-index',
        dataMenuConfig: []
      }
    },
    computed: mapGetters([
    ]),
    created: function () {
      this.dataMenuConfig = menuConfig
      this.getActiveIndex(this.dataMenuConfig)
    },
    methods: {
      menuItemSelect (menu) {
        this.$router.push(menu.path)
      },
      getActiveIndex (menus) {
        for (var i = 0; i < menus.length; i++) {
          let menu = menus[i]
          if (menu.items && menu.items.length > 0) {
            this.getActiveIndex(menu.items)
          } else {
            if (this.$route.path.indexOf(menu.path) > -1) {
              this.activeIndex = menu.iMenuId + ''
            }
          }
        }
      }
    }
  }
</script>
